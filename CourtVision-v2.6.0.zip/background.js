/**
 * CourtVision - Background Service Worker
 */

const STORAGE_KEY = 'courtvision_clips';

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getClips') {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      sendResponse(result[STORAGE_KEY] || []);
    });
    return true;
  }

  if (request.action === 'saveClip') {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      const clips = result[STORAGE_KEY] || [];
      clips.push(request.clip);
      chrome.storage.local.set({ [STORAGE_KEY]: clips }, () => {
        sendResponse({ success: true, clips: clips });
      });
    });
    return true;
  }

  if (request.action === 'deleteClip') {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      const clips = result[STORAGE_KEY] || [];
      const filtered = clips.filter(c => c.id !== request.clipId);
      chrome.storage.local.set({ [STORAGE_KEY]: filtered }, () => {
        sendResponse({ success: true, clips: filtered });
      });
    });
    return true;
  }

  if (request.action === 'clearAllClips') {
    chrome.storage.local.set({ [STORAGE_KEY]: [] }, () => {
      sendResponse({ success: true });
    });
    return true;
  }
});

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.storage.local.set({ [STORAGE_KEY]: [] });
  }
});

chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes[STORAGE_KEY]) {
    const clips = changes[STORAGE_KEY].newValue || [];
    const count = clips.length;
    
    chrome.action.setBadgeText({ 
      text: count > 0 ? count.toString() : '' 
    });
    chrome.action.setBadgeBackgroundColor({ 
      color: '#3B82F6' 
    });
  }
});
