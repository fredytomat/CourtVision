/**
 * CourtVision Popup - Full Clips Manager
 */

const STORAGE_KEY = 'courtvision_clips';
const CONFIG_KEY = 'courtvision_config';

let allClips = [];
let config = {
  teams: [
    { id: 'team-1', name: 'My Team', color: '#1E3A5F' },
    { id: 'team-2', name: 'Opponent', color: '#DC2626' }
  ],
  categories: []
};
let filterVideo = 'all';
let filterTeam = 'all';

// Format time helper
function formatTime(s) {
  if (isNaN(s)) return '0:00';
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return m + ':' + String(sec).padStart(2, '0');
}

// Load config from storage
async function loadConfig() {
  try {
    const result = await chrome.storage.local.get([CONFIG_KEY]);
    if (result[CONFIG_KEY]) {
      config = result[CONFIG_KEY];
    }
    updateTeamFilter();
  } catch (err) {
    console.error('Error loading config:', err);
  }
}

// Load clips from storage
async function loadClips() {
  try {
    await loadConfig();
    const result = await chrome.storage.local.get([STORAGE_KEY]);
    allClips = result[STORAGE_KEY] || [];
    updateStats();
    updateVideoFilter();
    renderClips();
  } catch (err) {
    console.error('Error loading clips:', err);
  }
}

// Update stats display
function updateStats() {
  const total = allClips.length;
  const success = allClips.filter(c => c.outcome === 'success').length;
  const fail = allClips.filter(c => c.outcome === 'fail').length;
  
  document.getElementById('stat-total').textContent = total;
  document.getElementById('stat-success').textContent = success;
  document.getElementById('stat-fail').textContent = fail;
}

// Update video filter dropdown
function updateVideoFilter() {
  const select = document.getElementById('filter-video');
  const videos = [...new Set(allClips.map(c => c.videoId))];
  
  select.innerHTML = '<option value="all">All Videos</option>';
  
  allClips.forEach(c => {
    if (!select.querySelector(`option[value="${c.videoId}"]`)) {
      const opt = document.createElement('option');
      opt.value = c.videoId;
      const title = c.videoTitle || 'Video';
      opt.textContent = title.length > 30 ? title.substring(0, 30) + '...' : title;
      select.appendChild(opt);
    }
  });
}

// Update team filter dropdown with dynamic teams
function updateTeamFilter() {
  const select = document.getElementById('filter-team');
  select.innerHTML = '<option value="all">All Teams</option>';
  
  config.teams.forEach(team => {
    const opt = document.createElement('option');
    opt.value = team.id;
    opt.textContent = team.name;
    select.appendChild(opt);
  });
}

// Render clips list
function renderClips() {
  const container = document.getElementById('clips-list');
  const emptyState = document.getElementById('empty-state');
  
  // Filter clips
  let filtered = allClips;
  
  if (filterVideo !== 'all') {
    filtered = filtered.filter(c => c.videoId === filterVideo);
  }
  
  if (filterTeam !== 'all') {
    filtered = filtered.filter(c => c.teamId === filterTeam);
  }
  
  // Sort by date (newest first)
  filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  
  if (filtered.length === 0) {
    emptyState.classList.remove('hidden');
    container.innerHTML = '';
    return;
  }
  
  emptyState.classList.add('hidden');
  
  // Group by video
  const groups = {};
  filtered.forEach(c => {
    const key = c.videoId;
    if (!groups[key]) {
      groups[key] = {
        title: c.videoTitle || 'Video',
        videoId: c.videoId,
        clips: []
      };
    }
    groups[key].clips.push(c);
  });
  
  // Render
  container.innerHTML = Object.values(groups).map(group => `
    <div class="video-group">
      <div class="video-title">${group.title}</div>
      ${group.clips.map(c => clipCardHTML(c)).join('')}
    </div>
  `).join('');
  
  // Attach listeners
  attachClipListeners();
}

// Generate clip card HTML
function clipCardHTML(c) {
  const outcomeClass = c.outcome === 'success' ? 'success' : c.outcome === 'fail' ? 'fail' : '';
  const outcomeText = c.outcome === 'success' ? 'OK' : c.outcome === 'fail' ? 'X' : '-';
  
  return `
    <div class="clip-card ${outcomeClass}" data-id="${c.id}">
      <div class="clip-header">
        <span class="clip-team" style="background: ${c.teamColor || '#3B82F6'}">${c.teamName || 'Tim'}</span>
        <span class="clip-cat">${c.categoryName || 'Category'}</span>
        <span class="clip-outcome ${outcomeClass}">${outcomeText}</span>
      </div>
      <div class="clip-time">${formatTime(c.startTime)} - ${formatTime(c.endTime)} <span class="clip-dur">${Math.round(c.endTime - c.startTime)}s</span></div>
      <div class="clip-adjust">
        <div class="adjust-row">
          <button class="adj-btn" data-id="${c.id}" data-type="start" data-dir="-1">-1s</button>
          <button class="adj-btn" data-id="${c.id}" data-type="start" data-dir="1">+1s</button>
          <span class="adjust-label">Start</span>
        </div>
        <div class="adjust-row">
          <button class="adj-btn" data-id="${c.id}" data-type="end" data-dir="-1">-1s</button>
          <button class="adj-btn" data-id="${c.id}" data-type="end" data-dir="1">+1s</button>
          <span class="adjust-label">End</span>
        </div>
      </div>
      <div class="clip-actions">
        <button class="clip-btn open" data-vid="${c.videoId}" data-start="${c.startTime}">Open in YouTube</button>
        <button class="clip-btn delete" data-id="${c.id}">X</button>
      </div>
    </div>
  `;
}

// Attach clip action listeners
function attachClipListeners() {
  // Open buttons
  document.querySelectorAll('.clip-btn.open').forEach(btn => {
    btn.onclick = () => {
      const vid = btn.dataset.vid;
      const start = Math.floor(parseFloat(btn.dataset.start));
      chrome.tabs.create({ url: `https://www.youtube.com/watch?v=${vid}&t=${start}s` });
    };
  });
  
  // Delete buttons
  document.querySelectorAll('.clip-btn.delete').forEach(btn => {
    btn.onclick = async () => {
      if (confirm('Delete this clip?')) {
        const id = btn.dataset.id;
        allClips = allClips.filter(c => c.id !== id);
        await chrome.storage.local.set({ [STORAGE_KEY]: allClips });
        loadClips();
      }
    };
  });

  // Adjust duration buttons
  document.querySelectorAll('.adj-btn').forEach(btn => {
    btn.onclick = async () => {
      const clipId = btn.dataset.id;
      const type = btn.dataset.type; // 'start' or 'end'
      const dir = parseInt(btn.dataset.dir); // -1 or 1
      
      const clip = allClips.find(c => c.id === clipId);
      
      if (clip) {
        if (type === 'start') {
          const newStart = clip.startTime + dir;
          if (newStart >= 0 && newStart < clip.endTime - 1) {
            clip.startTime = newStart;
          }
        } else if (type === 'end') {
          const newEnd = clip.endTime + dir;
          if (newEnd > clip.startTime + 1) {
            clip.endTime = newEnd;
          }
        }
        
        await chrome.storage.local.set({ [STORAGE_KEY]: allClips });
        renderClips();
      }
    };
  });
}

// Generate WhatsApp summary
function generateWhatsAppSummary(clips) {
  if (clips.length === 0) return '';
  
  const videoTitle = clips[0]?.videoTitle || 'Video';
  const shortTitle = videoTitle.length > 40 ? videoTitle.substring(0, 40) + '...' : videoTitle;
  
  // Group by team
  const teams = {};
  clips.forEach(c => {
    const teamKey = c.teamId || 'unknown';
    if (!teams[teamKey]) {
      teams[teamKey] = { name: c.teamName || 'Unknown', categories: {}, clips: [] };
    }
    const catKey = c.category;
    if (!teams[teamKey].categories[catKey]) {
      teams[teamKey].categories[catKey] = { name: c.categoryName, total: 0, success: 0, fail: 0 };
    }
    teams[teamKey].categories[catKey].total++;
    if (c.outcome === 'success') teams[teamKey].categories[catKey].success++;
    if (c.outcome === 'fail') teams[teamKey].categories[catKey].fail++;
    teams[teamKey].clips.push(c);
  });

  let text = `*GAME ANALYSIS*\n`;
  text += `${shortTitle}\n`;
  text += `${new Date().toLocaleDateString()}\n`;
  text += `━━━━━━━━━━━━━━━━\n\n`;

  Object.values(teams).forEach(team => {
    text += `*${team.name.toUpperCase()}*\n`;
    Object.values(team.categories).forEach(cat => {
      let line = `• ${cat.name}: ${cat.total}`;
      if (cat.success > 0 || cat.fail > 0) {
        const parts = [];
        if (cat.success > 0) parts.push(`${cat.success} ✓`);
        if (cat.fail > 0) parts.push(`${cat.fail} ✗`);
        line += ` (${parts.join(', ')})`;
      }
      text += line + '\n';
    });
    text += '\n';
  });

  const total = clips.length;
  const success = clips.filter(c => c.outcome === 'success').length;
  const fail = clips.filter(c => c.outcome === 'fail').length;
  
  text += `━━━━━━━━━━━━━━━━\n`;
  text += `*TOTAL: ${total} clips*\n`;
  if (success > 0) text += `✓ Made: ${success}\n`;
  if (fail > 0) text += `✗ Missed: ${fail}\n`;
  
  text += `\n━━━━━━━━━━━━━━━━\n`;
  text += `*CLIP LIST:*\n\n`;
  
  let clipNum = 1;
  Object.values(teams).forEach(team => {
    team.clips.sort((a, b) => a.startTime - b.startTime);
    team.clips.forEach(c => {
      const outcome = c.outcome === 'success' ? '✓' : c.outcome === 'fail' ? '✗' : '-';
      const url = `https://youtube.com/watch?v=${c.videoId}&t=${Math.floor(c.startTime)}s`;
      text += `${clipNum}. ${c.categoryName} (${team.name}) ${outcome}\n`;
      text += `   ${formatTime(c.startTime)} - ${formatTime(c.endTime)}\n`;
      text += `   ${url}\n\n`;
      clipNum++;
    });
  });
  
  text += `_CourtVision_`;
  
  return text;
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadClips();
  
  // Tab switching
  document.querySelectorAll('.tab').forEach(tab => {
    tab.onclick = () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(`tab-${tab.dataset.tab}`).classList.add('active');
    };
  });
  
  // Refresh button
  document.getElementById('btn-refresh').onclick = loadClips;
  
  // Video filter
  document.getElementById('filter-video').onchange = e => {
    filterVideo = e.target.value;
    renderClips();
  };
  
  // Team filter
  document.getElementById('filter-team').onchange = e => {
    filterTeam = e.target.value;
    renderClips();
  };
  
  // Copy WhatsApp
  document.getElementById('btn-copy-wa').onclick = async () => {
    let clips = allClips;
    if (filterVideo !== 'all') {
      clips = clips.filter(c => c.videoId === filterVideo);
    }
    
    if (clips.length === 0) {
      alert('No clips available');
      return;
    }
    
    const summary = generateWhatsAppSummary(clips);
    
    try {
      await navigator.clipboard.writeText(summary);
      alert('Copied! Paste to WhatsApp');
    } catch (err) {
      // Fallback
      const ta = document.createElement('textarea');
      ta.value = summary;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      alert('Copied! Paste to WhatsApp');
    }
  };
  
  // Export JSON
  document.getElementById('btn-export-json').onclick = () => {
    const blob = new Blob([JSON.stringify(allClips, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'courtvision.json';
    a.click();
    URL.revokeObjectURL(url);
  };
  
  // Export CSV
  document.getElementById('btn-export-csv').onclick = () => {
    let csv = 'Team,Category,Outcome,Video,Start,End,Duration,URL\n';
    allClips.forEach(c => {
      const dur = Math.round(c.endTime - c.startTime);
      const url = `https://www.youtube.com/watch?v=${c.videoId}&t=${Math.floor(c.startTime)}s`;
      const outcome = c.outcome === 'success' ? 'Made' : c.outcome === 'fail' ? 'Missed' : '-';
      csv += `"${c.teamName}","${c.categoryName}","${outcome}","${c.videoTitle}","${formatTime(c.startTime)}","${formatTime(c.endTime)}","${dur}s","${url}"\n`;
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'courtvision.csv';
    a.click();
    URL.revokeObjectURL(url);
  };
  
  // Clear all
  document.getElementById('btn-clear-all').onclick = async () => {
    if (confirm('Delete ALL clips? This action cannot be undone!')) {
      await chrome.storage.local.set({ [STORAGE_KEY]: [] });
      loadClips();
    }
  };
});
